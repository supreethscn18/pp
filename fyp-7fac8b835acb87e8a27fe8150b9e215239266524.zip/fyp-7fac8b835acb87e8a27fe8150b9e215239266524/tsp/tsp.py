#!/usr/bin/python3.5
# This u(x,i) are what are in the network.
# The v(x,i) is what we get after applying gou on the u(x,i)
# v(x,i) are what are used in the update rule.
import numpy as np
import pickle

u0 = 0.01
class params:
    A = 500
    B = 500
    C = 200
    D = 500


def gou(u):
    # todo : better to remove this from here
    from math import tanh
    global u0
    V = 0.5*(1 + tanh(u/u0))
    return V

# we are going to generate the co-ordinates of the given number of cities
# and then return a distance matrix for the same
def rand_city(count, x_max, y_max):
    # count is the number of cities
    # max_x and max_y are the maximum allowed ranges for the cities
    
    # this will store the list of cities
    cities = [None,None]
    dist = []
    # cities[0] = np.random.random(x_max,size = count)
    # cities[1] = np.random.random(y_max,size = count)

    cities[0] = np.random.random_sample(size = count)
    cities[1] = np.random.random_sample(size = count)
    cities = np.transpose(np.array(cities))
    # now the cities.shape is (count, 2)

    # now we calculate the distance matrix
    from math import sqrt as sqrt
    def dist_fx(a,b):
        return sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2)

    for i in range(len(cities)):
        dist.append([])
        for j in range(len(cities)):
            dist[i].append([])
            dist[i][j] = dist_fx(cities[i],cities[j])

    return cities, np.array(dist)


def energy_of(network, distances, cities):
    # This function will return the Energy corresponding to the current
    # cofiguration of the network using the distances betwwen the cities
    # from the distances parameter
    E = 0 # this is energy we return

    A = params.A # for the rows
    B = params.B # for the colums
    C = params.C # for the sum of N 1s
    D = params.D # for the actual route

    num_cities = len(cities)

    vectorised_gou = np.vectorize(gou)
    
    network = vectorised_gou(network)
    # now we go on adding terms to it

    # row constraint
    row_term = 0
    for row in network:
        row_on_row = np.matrix(row.reshape(-1,1)) * np.matrix(row.reshape(1,-1))

        # swap_0_and_1 is np.array and so is mask
        swap_0_and_1 = np.vectorize(lambda x : 0 if x == 1 else 1)
        mask = swap_0_and_1(np.identity(num_cities))

        # now we remove the diagonal of the matrix
        row_on_row = row_on_row * mask

        row_term += np.sum(row_on_row)
    
    E += (A / 2.0) * (row_term)
    # print("->", E)


    # column constraint
    column_term = 0
    for col in network.transpose():
        col_on_col = np.matrix(col.reshape(-1,1)) * np.matrix(col.reshape(1,-1))

        # swap_0_and_1 is np.array and so is mask
        swap_0_and_1 = np.vectorize(lambda x : 0 if x == 1 else 1)
        mask = swap_0_and_1(np.identity(num_cities))

        # now we remove the diagonal of the matrix
        col_on_col = col_on_col * mask

        column_term += np.sum(col_on_col)

    E += (B / 2.0) * (column_term)
    # print("-->", E)

    # the n_cities term
    n_cities_term = network.sum() - num_cities
    n_cities_term **= 2
    E += (C / 2.0 * n_cities_term)
    # print("--->", E)

    # the distance constraint
    total_distance = 0
    for x in range(num_cities):
        for y in range(num_cities):
            if y == x:
                continue
            for i in range(num_cities):
                total_distance += ( distances[x][y] * network[x][i] * 
                                (network[y][(i+1)%num_cities] + network[y][(i-1)%num_cities]) )

    E += (D / 2.0) * total_distance
    # print("---->", E)
    return E


def delta_uxi(network, distances, cities):
    # returns a matrix of the same shape as the netwotk and it has the deltas
    # to be add to the neurons.
    
    tou = 1
    num_cities = len(cities)

    A = params.A
    B = params.B
    C = params.C
    D = params.D

    vectorised_gou = np.vectorize(gou)
    V = vectorised_gou(network)

    delta_network = np.zeros((num_cities, num_cities))

    delta_network = np.array(network)
    delta_network = -delta_network / tou
    for x in range(num_cities):
        for i in range(num_cities):
            # along the row
            row_term = 0
            for j in range(num_cities):
                if i == j:
                    continue
                row_term += V[x][j]
            delta_network[x][i] -= A * row_term

            # along column
            column_term = 0
            for y in range(num_cities):
                if y == x:
                    continue
                column_term += V[y][i]
            delta_network[x][i] -= B * column_term

            # total count term
            count_term = 0
            for X in range(num_cities):
                for j in range(num_cities):
                    count_term += V[X][j]
            
            delta_network[x][i] -= C * (count_term - num_cities)

            # distance term
            distance_term = 0
            for y in range(num_cities):
                distance_term += distances[x][y] * (
                    V[y][(i+1)%num_cities]+
                    V[y][(i-1)%num_cities])
            delta_network[x][i] -= D * distance_term
    
    return delta_network

delta_t = 0.0001
def hopfield_tsp(cities, distances, target_axes, iteration_count):
    num_cities = len(cities)
    network = np.random.rand(num_cities, num_cities)
    # energy_line = target_axes.plot([0],[energy_of(network, distances, cities)])
    energy_line = target_axes.plot([],[])[0]
    xdata = []
    ydata = []
    
    true_iter = 0
    while True:
        for iteration in range(iteration_count): #*num_cities):
            # print(network)
            energy = energy_of(network, distances, cities)
            print ("Iteration", iteration, "Energy:", energy)
            delta = delta_uxi(network, distances, cities)
            network += (delta * delta_t)
            xdata.append(true_iter+iteration)
            ydata.append(energy)
            # energy_line.set_xdata(list(energy_line.get_xdata)+[iteration])
            # energy_line.set_ydata(list(energy_line.get_ydata)+[energy])
            # we get the energy then the deltas to be added
            # we make the changes and then iterate.
            # the network has the u(x,i)
        true_iter = len(ydata)

        # Now we set the x and y lim of the plot
        energy_line.set_xdata(xdata)
        energy_line.set_ydata(ydata)
        target_axes.set_xlim(left = 0, right = true_iter)
        target_axes.set_ylim(bottom=min(energy_line.get_ydata()) , top=max(energy_line.get_ydata()))
        vec_gou = np.vectorize(gou)
        print(np.around(vec_gou(network), decimals=2))
        ch = input()
        if ch != "y":
            break
    
def get_cmdline_args():
    # returns a parser required to parse the command line arguments
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-f", "--file", type=str)
    parser.add_argument("-n", "--ncity", type=int, default=10)
    parser.add_argument("--delta_t", type=float, default=0.00001, help="This is the analogue of the step size/learning rate")
    parser.add_argument("--u0", type=float, default=0.01, help="This is the gain value. It decides how drastic the activation function is. A lower value implies a more drastic curve.")
    parser.add_argument("--itercnt", type=int, default=100, help="This is the number of iterations that is run before we ask if we wish to continue or not.")
    return parser.parse_args()

if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import _thread
    
    args = get_cmdline_args()

    N_CITY = args.ncity
    MAX_X = 20
    MAX_Y = 20

    delta_t = args.delta_t
    u0 = args.u0
    iteration_count = args.itercnt

    # if we have passed it a file name then we better use that
    city, dist = None, None
    if args.file:
        city = pickle.load(open(args.file,"rb"))
        dist = []
        from math import sqrt as sqrt
        def dist_fx(a,b):
            return sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2)

        for i in range(len(city)):
            dist.append([])
            for j in range(len(city)):
                dist[i].append([])
                dist[i][j] = dist_fx(city[i],city[j])
    else:
        city, dist = rand_city(N_CITY, MAX_X, MAX_Y)
    print(city)
    for row in dist:
        print (row)

    #_thread.start_new_thread(plot_cities, (city,))
    plt.ion()
    cities_plot = plt.figure()
    ax = cities_plot.add_subplot(111)
    ax.scatter(city[:,0], city[:,1])

    # This for the energy function:
    energy_plot = plt.figure()
    energy_axes = energy_plot.add_subplot(111)
    energy_axes.set_autoscale_on(True)


    # _thread.start_new_thread(hopfield_tsp,(city, dist))
    # import threading
    # hnnt = threading.Thread(target=hopfield_tsp, args=(city, dist))
    # hnnt.start()

    hopfield_tsp(city,dist,energy_axes, iteration_count)
    input()
    # hnnt.join()
