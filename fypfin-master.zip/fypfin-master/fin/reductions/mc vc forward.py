def convert(l):
    return l
